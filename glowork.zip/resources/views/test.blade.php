<!DOCTYPE html>
<!-- 
Template Name: JB desks
Version: 1.0.0
Author: webstrot

-->
<!--[if IE 8]> <html lang="en" class="ie8 no-js"> <![endif]-->
<!--[if IE 9]> <html lang="en" class="ie9 no-js"> <![endif]-->
<!--[if !IE]><!-->
<html lang="zxx">
<!--[endif]-->

<head>
    <meta charset="utf-8" />
    <title>JB desks Responsive HTML Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta name="description" content="JB desks,job portal,job" />
    <meta name="keywords" content="JB desks,job portal,job" />
    <meta name="author" content="" />
    <meta name="MobileOptimized" content="320" />
    <!--Template style -->
    <link rel="stylesheet" type="text/css" href="css/animate.css" />
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
    <link rel="stylesheet" type="text/css" href="css/fonts.css" />
    <link rel="stylesheet" type="text/css" href="css/flaticon.css" />
    <link rel="stylesheet" type="text/css" href="css/font-awesome.css" />
    <link rel="stylesheet" type="text/css" href="css/owl.carousel.css">
    <link rel="stylesheet" type="text/css" href="css/owl.theme.default.css">
    <link rel="stylesheet" type="text/css" href="css/dropify.min.css" />
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css">
    <link rel="stylesheet" type="text/css" href="css/magnific-popup.css" />
    <link rel="stylesheet" type="text/css" href="css/nice-select.css" />
    <link rel="stylesheet" type="text/css" href="css/reset.css" />
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" type="text/css" href="css/responsive.css" />
    <!--favicon-->
    <link rel="shortcut icon" type="image/png" href="images/favicon.png" />
</head>

<body>
    <!-- preloader Start -->
    <!-- preloader Start -->
    <div class="jb_preloader">
        <div class="spinner_wrap">
            <div class="spinner"></div>
        </div>
    </div>
    <div class="cursor cursor2 cursor3"></div>
    <!-- Top Scroll Start --><a href="javascript:" id="return-to-top" class="return_top3"><i class="fas fa-angle-double-up"></i></a>
    <!-- Top Scroll End -->
    <!-- cp navi wrapper Start -->
    <nav class="cd-dropdown cd_dropdown_index2 cd_dropdown_index3 d-block d-sm-block d-md-block d-lg-none d-xl-none">
        <h2><a href="index.html"> <span><img src="images/logo5.png" alt="img"></span></a></h2>
        <a href="#0" class="cd-close">Close</a>
        <ul class="cd-dropdown-content">
            <li>
                <form class="cd-search">
                    <input type="search" placeholder="Search...">
                </form>
            </li>
            <li class="has-children">
                <a href="#">home</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="index.html">home I</a></li>
                    <li><a href="index_II.html">home II</a></li>
                    <li><a href="index_III.html">home III</a></li>
                </ul>
            </li>
            <li class="has-children">
                <a href="#">jobs</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="job_listing_grid_left_filter.html">job listing grid </a></li>
                    <li><a href="job_listing_list_left_filter.html">job listing list</a></li>
                    <li><a href="job_single.html">job single</a></li>
                </ul>
            </li>
            <!-- .has-children -->
            <li class="has-children">
                <a href="#">pages</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="about_us.html">about us</a></li>
                    <li><a href="companies.html">companies</a></li>
                    <li><a href="company_single.html">company single</a></li>
                    <li><a href="error_page.html">error page</a></li>
                    <li><a href="login.html">login</a></li>
                    <li><a href="pricing_table.html">pricing table</a></li>
                    <li><a href="sign_up.html">sign up</a></li>
                </ul>
            </li>
            <li class="has-children">
                <a href="#">dashboard</a>
                <ul class="cd-secondary-dropdown is-hidden">
                    <li class="go-back"><a href="#0">Menu</a>
                    </li>
                    <li class="has-children"> <a href="#">candidate</a>
                        <ul class="cd-secondary-dropdown is-hidden">
                            <li class="go-back"><a href="#0">Menu</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_applied_job.html">applied job </a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_dashboard.html">dashboard</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_edit_profile.html"> edit profile</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_favourite_job.html">favourite job</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_resume.html"> resume</a>
                            </li>
                            <li>
                                <a href="../dashboard/message.html"> message</a>
                            </li>
                            <li>
                                <a href="../dashboard/pricing_plans.html">pricing plans</a>
                            </li>
                        </ul>
                        <!-- .cd-secondary-dropdown -->
                    </li>
                    <!-- .has-children -->
                    <li class="has-children"> <a href="#">company</a>
                        <ul class="cd-secondary-dropdown is-hidden">
                            <li class="go-back"><a href="#0">Menu</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_applications.html"> applications </a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_company_page.html">company page</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_employer_dashboard.html"> dashboard</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_employer_edit_profile.html">edit profile</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_employer_manage_jobs.html"> manage jobs</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_post_new_job.html"> post new job</a>
                            </li>
                            <li>
                                <a href="../dashboard/message.html">message</a>
                            </li>
                            <li>
                                <a href="../dashboard/pricing_plans.html">pricing plans</a>
                            </li>
                        </ul>
                        <!-- .cd-secondary-dropdown -->
                    </li>
                </ul>
                <!-- .cd-secondary-dropdown -->
            </li>
            <li class="has-children">
                <a href="#">blog</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="blog_single.html">blog single</a></li>
                    <li><a href="blog_category_right_sidebar.html">blog category</a></li>
                </ul>
            </li>
            <li><a href="contact_us.html">contact us </a></li>
            <li><a href="login.html">login</a></li>
        </ul>
        <!-- .cd-dropdown-content -->
    </nav>
    <div class="cp_navi_main_wrapper index_2_top_header index_3_top_header jb_cover">

        <div class="cp_logo_wrapper index_2_logo index_3_logo">
            <a href="index_III.html">
                <img src="images/logo4.png" alt="logo">
            </a>
        </div>
        <!-- mobile menu area start -->
        <header class="mobail_menu d-block d-sm-block d-md-block d-lg-none d-xl-none">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="cd-dropdown-wrapper">
                            <a class="house_toggle" href="#0">
                                <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 31.177 31.177" style="enable-background:new 0 0 31.177 31.177;" xml:space="preserve" width="25px" height="25px">
                                    <g>
                                        <g>
                                            <path class="menubar" d="M30.23,1.775H0.946c-0.489,0-0.887-0.398-0.887-0.888S0.457,0,0.946,0H30.23    c0.49,0,0.888,0.398,0.888,0.888S30.72,1.775,30.23,1.775z" fill="#004165" />
                                        </g>
                                        <g>
                                            <path class="menubar" d="M30.23,9.126H12.069c-0.49,0-0.888-0.398-0.888-0.888c0-0.49,0.398-0.888,0.888-0.888H30.23    c0.49,0,0.888,0.397,0.888,0.888C31.118,8.729,30.72,9.126,30.23,9.126z" fill="#004165" />
                                        </g>
                                        <g>
                                            <path class="menubar" d="M30.23,16.477H0.946c-0.489,0-0.887-0.398-0.887-0.888c0-0.49,0.398-0.888,0.887-0.888H30.23    c0.49,0,0.888,0.397,0.888,0.888C31.118,16.079,30.72,16.477,30.23,16.477z" fill="#004165" />
                                        </g>
                                        <g>
                                            <path class="menubar" d="M30.23,23.826H12.069c-0.49,0-0.888-0.396-0.888-0.887c0-0.49,0.398-0.888,0.888-0.888H30.23    c0.49,0,0.888,0.397,0.888,0.888C31.118,23.43,30.72,23.826,30.23,23.826z" fill="#004165" />
                                        </g>
                                        <g>
                                            <path class="menubar" d="M30.23,31.177H0.946c-0.489,0-0.887-0.396-0.887-0.887c0-0.49,0.398-0.888,0.887-0.888H30.23    c0.49,0,0.888,0.398,0.888,0.888C31.118,30.78,30.72,31.177,30.23,31.177z" fill="#004165" />
                                        </g>
                                    </g>
                                </svg>
                            </a>
                            <!-- .cd-dropdown -->

                        </div>
                    </div>
                </div>
            </div>
            <!-- .cd-dropdown-wrapper -->
        </header>

        <div class="jb_navigation_wrapper index_2_right_menu index_3_right_menu">
            <div class="posting_job">
                <ul>
                    <li>
                        <div class="jb_search_btn_wrapper index_2_search d-none d-sm-none d-md-none d-lg-block d-xl-block">
                            <!-- extra nav -->
                            <div class="extra-nav">
                                <div class="extra-cell">
                                    <button id="quik-search-btn" type="button" class="site-button radius-xl"><i class="fas fa-search"></i></button>
                                </div>
                            </div>

                            <!-- Quik search -->
                            <div class="dez-quik-search bg-primary-dark">
                                <form action="#">
                                    <input name="search" value="" type="text" class="form-control" placeholder="Type to search...">
                                    <span id="quik-search-remove"><i class="fas fa-times"></i></span>
                                </form>
                            </div>
                        </div>
                    </li>
                    <li>
                        <div class="jb_profile_box jb_3_profile_box">
                            <div class="nice-select" tabindex="0"> <span class="current"><img src="images/pf.png" alt="img"></span>
                                <ul class="list">
                                    <li><a href="#"><i class="fas fa-user-edit"></i>Profile</a>
                                    </li>

                                    <li><a href="#"><i class="far fa-calendar-alt"></i> My Calender</a>
                                    </li>
                                    <li><a href="#"><i class="fas fa-comment"></i>Inbox</a>
                                    </li>
                                    <li><a href="#"><i class="fas fa-cog"></i>Setting</a>
                                    </li>
                                    <li><a href="#"><i class="fas fa-question-circle"></i>Help</a>
                                    </li>
                                    <li><a href="#"><i class="fas fa-lock"></i>Lock Screen</a>
                                    </li>
                                    <li><a href="#"><i class="fas fa-sign-in-alt"></i>logout</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                    <li class="btn_hover">
                         <a href="../dashboard/comp_post_new_job.html">post a job</a>
                    </li>
                </ul>
            </div>

            <div class="mainmenu green_main_menu blue_main_menu d-xl-block d-lg-block d-md-none d-sm-none d-none">
                <ul class="main_nav_ul menu_2_ul">
                    <li class="has-mega gc_main_navigation"><a href="#" class="gc_main_navigation active_class active_class2 active_class3">home</a>
                        <ul class="navi_2_dropdown">
                                <li class="parent">
                                    <a href="index.html"><i class="fas fa-square"></i>home I </a>
                                </li>
                                <li class="parent">
                                    <a href="index_II.html"><i class="fas fa-square"></i>home II</a>
                                </li>
                                <li class="parent">
                                    <a href="index_III.html"><i class="fas fa-square"></i> home III</a>
                                </li>

                            </ul>
                    </li>		
                    <li class="has-mega gc_main_navigation"><a href="#" class="gc_main_navigation">jobs</a>
                     <ul class="navi_2_dropdown">
                                <li class="parent">
                                    <a href="job_listing_grid_left_filter.html"> <i class="fas fa-square"></i>job listing grid </a>
                                </li>                    
                                <li class="parent">
                                    <a href="job_listing_list_left_filter.html"> <i class="fas fa-square"></i>job listing list </a>
                                </li>
                                <li class="parent">
                                    <a href="job_single.html"> <i class="fas fa-square"></i>job single</a>
                                </li>
                             
                                <li class="parent">
                                    <a href="#"><i class="fas fa-square"></i>jobs<span><i class="fas fa-chevron-right"></i>
									</span></a>
                                    <ul class="dropdown-menu-right">
                                        <li>
                                              <a href="job_listing_grid_left_filter.html"> <i class="fas fa-square"></i>job listing grid </a>
                                        </li>
                                        <li>
                                             <a href="job_listing_list_left_filter.html"> <i class="fas fa-square"></i>job listing list </a>
                                        </li>
                                        <li>
                                            <a href="job_single.html"> <i class="fas fa-square"></i>job single</a>
                                        </li>                 
                                    </ul>
                                </li>

                            </ul>
                    </li>
                    <li class="has-mega gc_main_navigation kv_sub_menu green_sub_menu blue_sub_menu">
                        <a href="#" class="gc_main_navigation">  candidates</a>
                        <!-- mega menu start -->
                        <ul class="kv_mega_menu">

                            <li class="kv_mega_menu_width">
                                <div class="container">

                                    <div class="jn_menu_partion_div">

                                        <div class="candidate_width">
                                            <div class="jen_tabs_conent_list jb_cover">
                                                <h1>job skills</h1>
                                                <ul>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>HTML5 & CSS3</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>wordpress</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>javascript</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>photoshop</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>designer</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>construction</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="candidate_width">
                                            <div class="jen_tabs_conent_list jb_cover">
                                                <h1>categories</h1>
                                                <ul>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>graphic design</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>engineering jobs</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>mainframe jobs</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>PSU jobs</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>goverment jobs</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>IT company</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="candidate_width">
                                            <div class="jen_tabs_conent_list   jb_cover">
                                                <h1>job location</h1>
                                                <ul>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>india</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>united state</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>japan</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>dubai</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>south africa</a>
                                                    </li>
                                                    <li>
                                                        <a href="#"><i class="fas fa-square"></i>china</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <div class="candidate_width">
                                            <div class="jen_tabs_conent_list   jb_cover">
                                                <h1>open jobs</h1>
                                                <div class="open_jobs_wrapper">
                                                    <div class="open_jobs_wrapper_1 jb_cover">
                                                        <img src="images/job1.jpg" alt="img">
                                                        <div class="open_job_text">
                                                            <h3><a href="#">Some designers 
inelevated the..</a></h3>
                                                            <p>5 hour ago</p>

                                                        </div>
                                                    </div>
                                                    <div class="open_jobs_wrapper_1 jb_cover">
                                                        <img src="images/job1.jpg" alt="img">
                                                        <div class="open_job_text">
                                                            <h3><a href="#">Some designers 
inelevated the..</a></h3>
                                                            <p>12 hour ago</p>

                                                        </div>
                                                    </div>
                                                    <div class="view_all_job jb_cover"><a href="#">view all jobs</a></div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>

                                </div>
                            </li>

                        </ul>
                    </li>
                    <li class="has-mega gc_main_navigation"><a href="#" class="gc_main_navigation">pages</a>
                        <ul class="navi_2_dropdown">
						  <li class="parent">
                                    <a href="about_us.html"> <i class="fas fa-square"></i>about us</a>
                                </li>
                                <li class="parent">
                                    <a href="companies.html"> <i class="fas fa-square"></i>companies</a>
                                </li>
                                <li class="parent">
                                    <a href="company_single.html"> <i class="fas fa-square"></i>company single</a>
                                </li>
                                <li class="parent">
                                    <a href="error_page.html"><i class="fas fa-square"></i>error page</a>
                                </li>
								 <li class="parent">
                                    <a href="login.html"><i class="fas fa-square"></i>login</a>
                                </li>
								 <li class="parent">
                                    <a href="pricing_table.html"><i class="fas fa-square"></i>pricing table</a>
                                </li>
								 <li class="parent">
                                    <a href="sign_up.html"><i class="fas fa-square"></i>sign_up</a>
                                </li>

                            </ul>
                    </li>
					 <li class="has-mega gc_main_navigation"><a href="#" class="gc_main_navigation">dashboard</a>
                            <ul class="navi_2_dropdown">
                                <li class="parent">
                                    <a href="#"><i class="fas fa-square"></i>candidate<span><i class="fas fa-chevron-right"></i>
									</span></a>
                                    <ul class="dropdown-menu-right">
                                        <li>
                                            <a href="../dashboard/candidate_applied_job.html"> <i class="fas fa-square"></i>applied job </a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/candidate_dashboard.html"> <i class="fas fa-square"></i> dashboard</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/candidate_edit_profile.html"> <i class="fas fa-square"></i>edit profile</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/candidate_favourite_job.html"> <i class="fas fa-square"></i>favourite job</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/candidate_resume.html"> <i class="fas fa-square"></i>resume</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/message.html"> <i class="fas fa-square"></i>message</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/pricing_plans.html"> <i class="fas fa-square"></i>pricing plans</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class="parent">
                                    <a href="#"><i class="fas fa-square"></i>company<span><i class="fas fa-chevron-right"></i>
									</span></a>
                                    <ul class="dropdown-menu-right">
                                        <li>
                                            <a href="../dashboard/comp_applications.html"> <i class="fas fa-square"></i>applications </a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/comp_company_page.html"> <i class="fas fa-square"></i> company page</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/comp_employer_dashboard.html"> <i class="fas fa-square"></i>dashboard</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/comp_employer_edit_profile.html"> <i class="fas fa-square"></i>edit profile</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/comp_employer_manage_jobs.html"> <i class="fas fa-square"></i>manage jobs</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/comp_post_new_job.html"> <i class="fas fa-square"></i>post new job</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/message.html"> <i class="fas fa-square"></i>message</a>
                                        </li>
                                        <li>
                                            <a href="../dashboard/pricing_plans.html"> <i class="fas fa-square"></i>pricing plans</a>
                                        </li>
                                    </ul>
                                </li>

                            </ul>
                        </li>
					 <li class="has-mega gc_main_navigation"><a href="#" class="gc_main_navigation">blog</a>
                          <ul class="navi_2_dropdown">
                                <li class="parent">
                                    <a href="blog_single.html"> <i class="fas fa-square"></i>blog single</a>
                                </li>
                                <li class="parent">
                                    <a href="blog_category_right_sidebar.html"> <i class="fas fa-square"></i>blog category</a>
                                </li>           
                            </ul>
                    </li>
                   <li><a href="contact_us.html" class="gc_main_navigation">contact</a></li>

                </ul>
            </div>
            <!-- mainmenu end -->

        </div>
    </div>

    <!-- navi wrapper End -->

    <!-- slider wrapper Start -->
    <div class="main_slider_wrapper slider-area jb_cover">
        <div class="mains_slider_shaper">
            <img src="images/slider_bg.png" class="img-responsive" alt="img">
        </div>
        <div class="slider_small2_shape">
            <img src="images/shape4.png" class="img-responsive " alt="img">
        </div>
        <div class="slider_shape_smt bubble-1">
            <img src="images/bubble.png" class="img-responsive " alt="img">
        </div>
        <div id="carousel-example-generic" class="carousel slide" data-ride="carousel" data-interval="false">
            <div class="carousel-inner" role="listbox">
                <div class="carousel-item active">
                    <div class="carousel-captions caption-1">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="content">
                                        <div class="slider_shape_smt1 bubble-2">
                                            <img src="images/bubble.png" class="img-responsive " alt="img">
                                        </div>
                                        <h2 data-animation="animated fadeInUp">We Offer <span> 25,000 </span>Job
Vacancies Right Now!.</h2>

                                        <p data-animation="animated fadeInUp">The most complete field service software for IT & Mobile Support, Fire Services, Electrical, Maintenance, HVAC & Security Industries</p>
                                        <div data-animation="animated fadeInUp" class="btn_hover slider_btn">
                                            <a href="#">sign up free</a>
                                        </div>
                                        <div data-animation="animated fadeInUp" class="slider_icon_list">
                                            <ul>

                                                <li><a href="#"><i class="fab fa-apple"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fab fa-amazon"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fab fa-angular"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fas fa-th-large"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fas fa-blog"></i></a>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="slider_shape_sm3 bubble-3">
                                        <img src="images/bubble.png" class="img-responsive " alt="img">
                                    </div>
                                    <div class="slider_side_img jb_cover">
                                        <img src="images/slider_img.png" class="img-responsive" alt="img">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="carousel-captions caption-2">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="content">
                                        <div class="slider_shape_smt1 bubble-4">
                                            <img src="images/bubble.png" class="img-responsive" alt="img">
                                        </div>
                                        <h2 data-animation="animated fadeInUp">We Offer <span> 25,000 </span>Job
Vacancies Right Now!.</h2>

                                        <p data-animation="animated fadeInUp">The most complete field service software for IT & Mobile Support, Fire Services, Electrical, Maintenance, HVAC & Security Industries</p>
                                        <div data-animation="animated fadeInUp" class="btn_hover slider_btn">
                                            <a href="#">sign up free</a>
                                        </div>
                                        <div data-animation="animated fadeInUp" class="slider_icon_list">
                                            <ul>

                                                <li><a href="#"><i class="fab fa-apple"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fab fa-amazon"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fab fa-angular"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fas fa-th-large"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fas fa-blog"></i></a>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="slider_shape_sm3 bubble-5">
                                        <img src="images/bubble.png" class="img-responsive" alt="img">
                                    </div>
                                    <div class="slider_side_img jb_cover">
                                        <img src="images/slider_img.png" class="img-responsive" alt="img">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="carousel-item">
                    <div class="carousel-captions caption-3">
                        <div class="container">
                            <div class="row">
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="content">
                                        <div class="slider_shape_smt1 bubble-6">
                                            <img src="images/bubble.png" class="img-responsive" alt="img">
                                        </div>
                                        <h2 data-animation="animated fadeInUp">We Offer <span> 25,000 </span>Job
Vacancies Right Now!.</h2>

                                        <p data-animation="animated fadeInUp">The most complete field service software for IT & Mobile Support, Fire Services, Electrical, Maintenance, HVAC & Security Industries</p>
                                        <div data-animation="animated fadeInUp" class="btn_hover slider_btn">
                                            <a href="#">sign up free</a>
                                        </div>
                                        <div data-animation="animated fadeInUp" class="slider_icon_list">
                                            <ul>

                                                <li><a href="#"><i class="fab fa-apple"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fab fa-amazon"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fab fa-angular"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fas fa-th-large"></i></a>
                                                </li>
                                                <li><a href="#"><i class="fas fa-blog"></i></a>
                                                </li>

                                            </ul>
                                        </div>
                                        <div class="clear"></div>
                                    </div>
                                </div>
                                <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                                    <div class="slider_shape_sm3 bubble-7">
                                        <img src="images/bubble.png" class="img-responsive" alt="img">
                                    </div>
                                    <div class="slider_side_img jb_cover">
                                        <img src="images/slider_img.png" class="img-responsive" alt="img">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <ol class="carousel-indicators">
                    <li data-target="#carousel-example-generic" data-slide-to="0" class="active">
                    </li>
                    <li data-target="#carousel-example-generic" data-slide-to="1" class="">
                    </li>
                    <li data-target="#carousel-example-generic" data-slide-to="2" class="">
                    </li>
                </ol>
                <div class="carousel-nevigation">
                    <a class="prev" href="#carousel-example-generic" role="button" data-slide="prev"><i class="flaticon-left-arrow"></i>
					</a>
                    <a class="next" href="#carousel-example-generic" role="button" data-slide="next"><i class="flaticon-right-arrow"></i>
					</a>
                </div>
            </div>
        </div>
        <div class="slider_small_shape">
            <img src="images/shape4.png" class="img-responsive" alt="img">
        </div>
    </div>

    <!-- slider wrapper End -->
   
   
   
   
    <!--services wrapper start-->
    <div class="index3_form_wrapper jb_cover">
        <div class="slider_small3_shape">
            <img src="images/shape4.png" class="img-responsive" alt="img">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="index3_form_box jb_cover">
                        <div class="select_box select_box3">

                            <select>
                                <option>category</option>
                                <option>real estate</option>
                                <option>electronics</option>
                                <option>marketing</option>
                                <option>education</option>

                            </select>

                        </div>
                        <div class="select_box select_box3">

                            <select>
                                <option>job title</option>
                                <option>teacher</option>
                                <option>marketing</option>
                                <option>doctor</option>
                                <option>graphic</option>

                            </select>

                        </div>
                        <div class="select_box select_box3">

                            <select>
                                <option>location</option>
                                <option>pune</option>
                                <option>banglore</option>
                                <option>indore</option>
                                <option>bhopal</option>

                            </select>

                        </div>
                        <div class="contect_form3 contct_form_new3">

                            <input type="text" name="name" placeholder="Keyword">
                        </div>
                        <div class="index3_form_search">
                            <a href="#"><i class="fas fa-search"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--service wrapper end-->
    <!-- best jobs wrapper start-->
    <div class="best_jobs_wrapper index3_best_job_wrapper  jb_cover">
        <div class="line_shape">
            <img src="images/line.png" class="img-responsive" alt="img">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>Our Best Jobs for You</h3>

                        <p>Your next level Product developemnt company assets</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">

                    <div class="latest_job_tabs index2_tab_wrapper index3_tab_wrapper jb_cover">
                        <ul class="nav nav-tabs">
                            <li class="nav-item"> <a class="nav-link active" data-toggle="tab" href="#home"> latest job</a>
                            </li>
                            <li class="nav-item"> <a class="nav-link " data-toggle="tab" href="#menu1">popular job</a>
                            </li>

                        </ul>
                    </div>

                </div>
                <div class="col-xl-12 col-lg-12 col-md-12">
                    <div class="tab-content">
                        <div id="home" class="tab-pane active">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt5.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">web  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt2.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">web  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt3.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">php  developer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt4.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">graphic  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt5.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">software eng. </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt3.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">UI/UX  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div id="menu1" class="tab-pane fade">
                            <div class="row">
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt2.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">web  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt3.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">php  developer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt4.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">graphic  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt5.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">software eng. </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt5.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">wordpress developer</a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 col-md-12 col-sm-12">

                                    <div class="job_listing_left_fullwidth job_listing_grid_wrapper index2_listing_jobs index3_listing_jobs jb_cover">
                                        <div class="row">
                                            <div class="col-lg-12 col-md-12 col-sm-12 col-12">

                                                <div class="jp_job_post_side_img">
                                                    <img src="images/lt1.png" alt="post_img" />

                                                </div>
                                                <div class="jp_job_post_right_cont">
                                                    <h4><a href="#">graphic  Designer </a></h4>

                                                    <ul>
                                                        <li><i class="flaticon-cash"></i>&nbsp; $12K - 15k P.A.</li>
                                                        <li><i class="flaticon-location-pointer"></i>&nbsp; RG40, Wokingham</li>
                                                    </ul>
                                                    <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco.</p>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="btn_hover slider_btn jobs_btn_3 jb_cover">
                        <a href="#">view all</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="slider_small3_shape">
            <img src="images/shape4.png" class="img-responsive" alt="img">
        </div>
    </div>

    <!-- best jobs wrapper end-->
    <!-- counter wrapper start-->
    <div class="counter_wrapper counter_3_wrapper jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="counter_mockup_design jb_cover">

                        <img src="images/mockup6.png" class="img-responsive" alt="img">
                    </div>
                    <div class="counter_jbbb jb_cover">

                        <img src="images/line2.png" class="img-responsive" alt="img">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="counter_right_wrapper counter_index3_right jb_cover">
                        <h1>Some Statistical Facts</h1>
                        <div class="counter_width">
                            <div class="counter_cntnt_box">

                                <div class="count-description"><span class="timer">2500</span>
                                    <p class="con2">happy customers </p>
                                </div>
                            </div>
                        </div>
                        <div class="counter_width">
                            <div class="counter_cntnt_box">

                                <div class="count-description"> <span class="timer">9425</span>
                                    <p class="con2">ticket solved</p>
                                </div>
                            </div>
                        </div>
                        <div class="counter_width">
                            <div class="counter_cntnt_box">

                                <div class="count-description"> <span class="timer">9</span><span>+</span>
                                    <p class="con2">average rating</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- counter wrapper end-->
    <!--services wrapper start-->
    <div class="services_wrapper control_wrapper jb_cover">
        <div class="slider_small_shape44">
            <img src="images/shape4.png" class="img-responsive " alt="img">
        </div>
        <div class="counter_jbbb2 jb_cover">

            <img src="images/line3.png" class="img-responsive" alt="img">
        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>Control everything from your business
</h3>

                        <p>Your next level Product developemnt company assets</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c1.png" alt="img">
                        <h3><a href="#">job managment </a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c2.png" alt="img">
                        <h3><a href="#">eassy pay money</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c3.png" alt="img">
                        <h3><a href="#">flexible invoicing</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c4.png" alt="img">
                        <h3><a href="#">Compliance Reporting</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c5.png" alt="img">
                        <h3><a href="#">job schedule</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c6.png" alt="img">
                        <h3><a href="#">safety checklists</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c7.png" alt="img">
                        <h3><a href="#">assest managment</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c8.png" alt="img">
                        <h3><a href="#">job notifications</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
                <div class="col-lg-4 col-md-6 col-sm-12 col-xs-12">
                    <div class="services_content jb_cover">
                        <img src="images/c9.png" alt="img">
                        <h3><a href="#">customer portal</a></h3>
                        <p>Create jobs, allocate to technicians, track time & materials to determine job profitability </p>

                    </div>
                </div>
            </div>
        </div>
        <div class="slider_small3_shape">
            <img src="images/shape4.png" class="img-responsive" alt="img">
        </div>

    </div>
    <!--services wrapper end-->
    <!-- download app wrapper start-->
    <div class="download_wrapper index3_download jb_cover">
        <div class="line_shape">
            <img src="images/line.png" class="img-responsive" alt="img">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="download_mockup_design jb_cover">

                        <img src="images/mockup7.png" class="img-responsive" alt="img">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="download_app_store jb_cover">
                        <h1>Download</h1>
                        <h2>Job Portal App Now!</h2>
                        <p>All it takes is 30 seconds to Download. Your Mobile App for Job
                            <br> Fast, Simple & Delightful.</p>
                        <div class="app_btn playstore_2 jb_cover">
                            <a href="#" class="ss_playstore"><span><i class="flaticon-android-logo"></i></span> Play Store</a>
                            <a href="#" class="ss_appstore"><span><i class="flaticon-apple"></i></span> App Store</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- download app wrapper end-->
    <!--clients wrapper start-->
    <div class="client_wrapper_top jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>our happy clients
</h3>

                        <p>Your next level Product developemnt company assets</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="client_wrapper jb_cover">
                        <div class="owl-carousel owl-theme">
                            <div class="item">
                                <div class="row">
                                    <div class="col-xl-8 col-lg-12 col-md-12 col-sm-12">
                                        <div class="client_wrapper_cntnt jb_cover">
                                            <div class="client_shap1 bubble-5">
                                                <img src="images/bubble.png" class="img-responsive" alt="img">
                                            </div>
                                            <div class="client_shap2 bubble-7">
                                                <img src="images/bubble.png" class="img-responsive" alt="img">
                                            </div>
                                            <img src="images/quote1.png" alt="img">

                                            <h1><a href="#">Marita Irene</a> <span>(business)</span></h1>

                                            <p>Packages and web page editors now use Lorem Ipsum as their am efault model text yr,and a search.</p>
                                            <div class="client_shap3 bubble-6">
                                                <img src="images/bubble.png" class="img-responsive" alt="img">
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-xl-4 col-lg-12 col-md-12 col-sm-12">
                                        <div class="clinnt_slider_img jb_cover">
                                            <img src="images/vv.png" class="img-responsive" alt="img">
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="item">
                                <div class="row">
                                    <div class="col-xl-8 col-lg-12 col-md-12 col-sm-12">
                                        <div class="client_wrapper_cntnt jb_cover">
                                            <div class="client_shap1 bubble-8">
                                                <img src="images/bubble.png" class="img-responsive" alt="img">
                                            </div>
                                            <div class="client_shap2 bubble-9">
                                                <img src="images/bubble.png" class="img-responsive" alt="img">
                                            </div>
                                            <img src="images/quote1.png" alt="img">

                                            <h1><a href="#">Marita Irene</a> <span>(business)</span></h1>

                                            <p>Packages and web page editors now use Lorem Ipsum as their am efault model text yr,and a search.</p>
                                            <div class="client_shap3 bubble-6">
                                                <img src="images/bubble.png" class="img-responsive" alt="img">
                                            </div>
                                        </div>
                                    </div>
                                      <div class="col-xl-4 col-lg-12 col-md-12 col-sm-12">
                                        <div class="clinnt_slider_img jb_cover">
                                            <img src="images/vv.png" class="img-responsive" alt="img">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="slider_small3_shape shapenew">
            <img src="images/shape4.png" class="img-responsive" alt="img">
        </div>
    </div>
    <!--clients wrapper end-->
    <!--pricing table start-->
    <div class="pricing_table_3 jb_cover">
        <div class="line_shape">
            <img src="images/line.png" class="img-responsive" alt="img">
        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>choose pricing plan
</h3>

                        <p>Your next level Product developemnt company assets</p>
                    </div>
                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                    <div class="pricing_box_wrapper index2_pricing_wrapper index3_pricing_wrapper jb_cover">
                        <h1>basic plan</h1>
                        <div class="main_pdet jb_cover">

                            <h2><span class="dollarr"> $ </span> 19 <br> <span>/ per month</span> </h2>

                        </div>

                        <ul class="pricing_list22">

                            <li>5 Jobs Posting
                            </li>
                            <li>2 Featured jobs
                            </li>
                            <li>
                                1 Renew Jobs

                            </li>
                            <li>10 Days Duration
                            </li>
                            <li>Email Alert

                            </li>

                        </ul>
                        <a href="#" class="price_btn">select plan</a>

                    </div>

                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                    <div class="pricing_box_wrapper index2_pricing_wrapper index3_pricing_wrapper jb_cover">
                        <h1>premium plan</h1>
                        <div class="main_pdet jb_cover">

                            <h2><span class="dollarr"> $ </span> 29 <br> <span>/ per month</span> </h2>

                        </div>
                        <ul class="pricing_list22">
                            <li>5 Jobs Posting
                            </li>
                            <li>2 Featured jobs
                            </li>
                            <li>
                                1 Renew Jobs

                            </li>
                            <li>10 Days Duration
                            </li>
                            <li>Email Alert

                            </li>

                        </ul>
                        <a href="#" class="price_btn">select plan</a>
                    </div>

                </div>
                <div class="col-lg-4 col-md-12 col-sm-12 col-12">
                    <div class="pricing_box_wrapper index2_pricing_wrapper index3_pricing_wrapper jb_cover">
                        <h1>premium plan</h1>
                        <div class="main_pdet jb_cover">

                            <h2><span class="dollarr"> $ </span> 59 <br> <span>/ per month</span> </h2>

                        </div>
                        <ul class="pricing_list22">
                            <li>5 Jobs Posting
                            </li>
                            <li>2 Featured jobs
                            </li>
                            <li>
                                1 Renew Jobs

                            </li>
                            <li>10 Days Duration
                            </li>
                            <li>Email Alert

                            </li>

                        </ul>
                        <a href="#" class="price_btn">select plan</a>
                    </div>

                </div>
            </div>
        </div>

        <div class="counter_jbbb2 jb_cover">

            <img src="images/line3.png" class="img-responsive" alt="img">
        </div>
    </div>
    <!--pricing table end-->
    <!--popular wrapper start-->
    <div class="popular_wrapper jb_cover">
        <div class="slider_small3_shape shapenew">
            <img src="images/shape4.png" class="img-responsive " alt="img">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>We are Popular Everywhere
</h3>

                        <p>Your next level Product developemnt company assets</p>
                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12 col-12">
                    <div class="jp_register_section_main_wrapper jb_cover">
                        <div class="jp_regis_left_side_box_wrapper">
                            <div class="jp_regis_left_side_box">
                                <i class="flaticon-laptop"></i>
                                <h4>I’m an employer</h4>
                                <p>Signed in companies are able to post new
                                    <br> job offers, searching for candidate...</p>
                                <ul>
                                    <li><a href="#" class="price_btn regis_btn"> register as company</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="jp_regis_right_side_box_wrapper">

                            <div class="jp_regis_right_side_box">
                                <i class="flaticon-doctor"></i>
                                <h4>I’m an candidate</h4>
                                <p>Signed in companies are able to post new
                                    <br> job offers, searching for candidate...</p>
                                <ul>
                                    <li><a href="#" class="price_btn regis_btn">register as candidate</a></li>
                                </ul>
                            </div>
                            <div class="jp_regis_center_tag_wrapper">
                                <p>OR</p>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--popular wrapper end-->
    <!--resume wrapper start-->
    <div class="pricing_table_3 recent_resume_wrapper jb_cover">
        <div class="slider_small_shape44">
            <img src="images/p2.png" class="img-responsive " alt="img">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>recent resume
</h3>

                        <p>Your next level Product developemnt company assets</p>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-12">
                    <div class="jp_recent_resume_box_wrapper jb_cover">
                        <div class="jp_recent_resume_img_wrapper">
                            <img src="images/cmnt4.jpg" alt="resume_img" />
                        </div>
                        <div class="jp_recent_resume_cont_wrapper">
                            <h3> <a href="#">Akshay Handge</a></h3>
                            <p><i class="far fa-folder-open"></i>UI Designer</p>
                        </div>
                        <div class="jp_recent_resume_btn_wrapper">
                            <ul>
                                <li><a href="#">View Profile</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="jp_recent_resume_box_wrapper jb_cover">
                        <div class="jp_recent_resume_img_wrapper">
                            <img src="images/cmnt1.jpg" alt="resume_img" />
                        </div>
                        <div class="jp_recent_resume_cont_wrapper">
                            <h3><a href="#">aditi S.</a></h3>
                            <p><i class="far fa-folder-open"></i> I Designer</p>
                        </div>
                        <div class="jp_recent_resume_btn_wrapper">
                            <ul>
                                <li><a href="#">View Profile</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="jp_recent_resume_box_wrapper jb_cover">
                        <div class="jp_recent_resume_img_wrapper">
                            <img src="images/cmnt2.jpg" alt="resume_img" />
                        </div>
                        <div class="jp_recent_resume_cont_wrapper">
                            <h3><a href="#">Merry Foster</a></h3>
                            <p><i class="far fa-folder-open"></i>UI Designer</p>
                        </div>
                        <div class="jp_recent_resume_btn_wrapper">
                            <ul>
                                <li><a href="#">View Profile</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="jp_recent_resume_box_wrapper jb_cover">
                        <div class="jp_recent_resume_img_wrapper">
                            <img src="images/cmnt3.jpg" alt="resume_img" />
                        </div>
                        <div class="jp_recent_resume_cont_wrapper">
                            <h3> <a href="#">joahn due</a></h3>
                            <p><i class="far fa-folder-open"></i>UI Designer</p>
                        </div>
                        <div class="jp_recent_resume_btn_wrapper">
                            <ul>
                                <li><a href="#">View Profile</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="btn_hover slider_btn jobs_btn_3 vb jb_cover">
                    <a href="#">view all</a>
                </div>
            </div>
        </div>
        <div class="counter_jbbb2 jb_cover">

            <img src="images/line3.png" class="img-responsive" alt="img">
        </div>
    </div>
    <!--resume wrapper end-->
    <!-- news app wrapper start-->
    <div class="news_letter_wrapper shaa jb_cover">
        <div class="sha1 bubble-180">
            <img src="images/bubble2.png" class="img-responsive " alt="img">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="job_newsletter_wrapper jb_cover">
                        <div class="jb_newslwtteter_left">
                            <h2> Looking For A Job</h2>
                            <p>Your next level Product developemnt company assetsYour next level Product </p>
                        </div>
                        <div class="jb_newslwtteter_button">
                            <div class="btn_hover slider_btn jobs_btn_3">
                                <a href="#">submit</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="sha2 bubble-185">
            <img src="images/bubble2.png" class="img-responsive " alt="img">
        </div>
    </div>
    <!-- news app wrapper end-->
    <!-- footer Wrapper Start -->
    <div class="footer index2_footer_wrapper footer_index3 shaa jb_cover">
        <div class="ft_shape bubble-18">
            <img src="images/bubble2.png" class="img-responsive " alt="img">
        </div>

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover">
                        <a href="#"><img src="images/logo5.png" alt="img"></a>
                        <ul class="footer_first_contact">
                            <li><i class="flaticon-location-pointer"></i>
                                <p>123 City Avenue, Floor 10,
                                    <br> malbourne, Australia.
                                </p>
                            </li>
                            <li><i class="flaticon-telephone"></i>
                                <p>1 -234 -456 -7890
                                    <br> 1 -234 -456 -7890</p>
                            </li>
                            <li><i class="flaticon-envelope"></i><a href="#">info@Jbdesks.com </a>
                                <br>
                                <a href="#">support@Jbdesks.com</a>
                            </li>

                        </ul>

                        <ul class="icon_list_news index2_icon_list jb_cover">
                            <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                            <li>
                                <a href="#"><i class="fab fa-twitter"></i>
                                    </a>
                            </li>
                            <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover footer_border_displ">
                        <h5>features</h5>
                        <ul class="nav-widget">
                            <li><a href="#"><i class="fa fa-square"></i>Job Management & Billing
</a></li>

                            <li><a href="#"><i class="fa fa-square"></i>Time & Materials Tracking
</a></li>

                            <li><a href="#"><i class="fa fa-square"></i>Standards Compliance 
</a></li>

                            <li><a href="#"><i class="fa fa-square"></i>Real Time GPS Tracking
</a></li>

                            <li><a href="#"><i class="fa fa-square"></i>Client Portal
</a></li>

                            <li><a href="#"><i class="fa fa-square"></i> Powerful Workflow</a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover footer_border_displ">
                        <h5>browse</h5>
                        <ul class="nav-widget">

                            <li><a href="#"><i class="fa fa-square"></i>Freelancers by Category</a></li>

                            <li><a href="#"><i class="fa fa-square"></i> Freelancers in USA </a></li>

                            <li><a href="#"><i class="fa fa-square"></i> Freelancers in UK</a></li>

                            <li><a href="#"><i class="fa fa-square"></i> Freelancers in Canada</a></li>
                            <li><a href="#"><i class="fa fa-square"></i> Freelancers in india</a></li>
                            <li><a href="#"><i class="fa fa-square"></i> find jobs</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover footer_border_displ">
                        <h5>app & integration</h5>
                        <ul class="nav-widget">
                            <li>
                                <a href="#"><img src="images/ft1.png" alt="img">Xero
                                </a>
                            </li>

                            <li>
                                <a href="#"><img src="images/ft2.png" alt="img">Reckon
                                </a>
                            </li>

                            <li>
                                <a href="#"><img src="images/ft3.png" alt="img">Flexidocs
                                </a>
                            </li>
                            <li>
                                <a href="#"><img src="images/ft4.png" alt="img">Microsoft Exchange</a>
                            </li>
                            <li>
                                <a href="#"><img src="images/ft5.png" alt="img"> Mailchimp
                                </a>
                            </li>
                            <li>
                                <a href="#"><img src="images/ft6.png" alt="img"> MYOB
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
                <div class="copyright_left"><i class="fa fa-copyright"></i> 2019 <a href="#">  JB desks.  </a> All Rights Reserved.
                </div>

                <div class="clearfix"></div>
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
        <div class="waveWrapper waveAnimation">
            <div class="waveWrapperInner bgTop gradient-color">
                <div class="wave waveTop wavetop_1 wavetop_3"></div>
            </div>
            <div class="waveWrapperInner bgMiddle">
                <div class="wave waveMiddle"></div>
            </div>
            <div class="waveWrapperInner bgBottom">
                <div class="wave waveBottom wavebottom_1 wavebottom_3"></div>
            </div>
        </div>
        <div class="ft_shape2 bubble-190">
            <img src="images/bubble2.png" class="img-responsive " alt="img">
        </div>
        <div class="ft_shape1 bubble-19">
            <img src="images/bubble2.png" class="img-responsive " alt="img">
        </div>
    </div>

    <!-- footer Wrapper End -->
	 <!-- chat box Wrapper start -->
	<div id="chat-circle" class="btn btn-raised circle_index3"> 
		<i class="fas fa-comment-alt"></i>
	</div>
  <div class="chat-box chat_box_3">
    <div class="chat-box-header">
      ChatBot
      <span class="chat-box-toggle"><i class="fas fa-times"></i></span>
    </div>
    <div class="chat-box-body chat_msg_box22">
      <div class="chat-box-overlay">   
      </div>
      <div class="chat-logs">
       
      </div><!--chat-log -->
    </div>
    <div class="chat-input">      
      <form>
        <input type="text" id="chat-input" placeholder="Send a message..."/>
      <button type="submit" class="chat-submit" id="chat-submit"><i class="fas fa-paper-plane"></i></button>
      </form>      
    </div>
  </div>
  <!-- chat box Wrapper end -->
    <!--custom js files-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/jquery.menu-aim.js"></script>
    <script src="js/plugin.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery-ui.js"></script>
    <script src="js/jquery.countTo.js"></script>
    <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/dropify.min.js"></script>
    <script src="js/jquery.inview.min.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- custom js-->
</body>

</html>