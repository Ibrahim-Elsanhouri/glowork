<!DOCTYPE html>
<html lang="zxx">
<!--[endif]-->

<head>
    <meta charset="utf-8" />
    <title>Glowork</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport" />
    <meta name="description" content="Glowork,job portal,job" />
    <meta name="keywords" content="Glowork,job portal,job" />
    <meta name="author" content="" />
    <meta name="MobileOptimized" content="320" />
    <!--Template style -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/animate.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/fonts.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/flaticon.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/font-awesome.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/owl.theme.default.css ')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/dropify.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/magnific-popup.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/nice-select.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/reset.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/responsive.css')); ?>" />
    


    
    <!--favicon-->


        <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/animate.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/fonts.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/flaticon.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/font-awesome.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/owl.carousel.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/owl.theme.default.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/magnific-popup.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/dropify.min.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/nice-select.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/jquery-ui.min.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('dashboard/css/reset.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="css/responsive.css" />



        <!--Dashboard-->









    <link rel="shortcut icon" type="image/png" href="<?php echo e(asset('images/glowork-logo.jpg')); ?>" />
</head>

<body>
    <!-- preloader Start -->
    <div class="jb_preloader">
        <div class="spinner_wrap">
            <div class="spinner"></div>
        </div>
    </div>
   <!-- <div class="cursor"></div> -->
    <!-- Top Scroll Start --><a href="javascript:" id="return-to-top"><i class="fas fa-angle-double-up"></i></a>
    <!-- Top Scroll End -->
    <!-- cp navi wrapper Start -->
    <nav class="cd-dropdown  d-block d-sm-block d-md-block d-lg-none d-xl-none">
        <h2><a href="/"> <span><img src="images/glowork-logo.jpg" alt="img"></span></a></h2>
        <a href="#0" class="cd-close">Close</a>
        <ul class="cd-dropdown-content">
            <li>
                <form class="cd-search">
                    <input type="search" placeholder="Search...">
                </form>
            </li>
            <li>
                <a href="/">home</a>
            
            </li>
            <li class="has-children">
                <a href="#">jobssssssss</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="job_listing_grid_left_filter.html">job listing grid </a></li>
                    <li><a href="job_listing_list_left_filter.html">job listing list</a></li>
                    <li><a href="job_single.html">job single</a></li>
                </ul>
            </li>
            <!-- .has-children -->
            <li class="has-children">
                <a href="#">pages</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="about_us.html">about us</a></li>
                    <li><a href="companies.html">companies</a></li>
                    <li><a href="company_single.html">company single</a></li>
                    <li><a href="error_page.html">error page</a></li>
                    <li><a href="login.html">login</a></li>
                    <li><a href="pricing_table.html">pricing table</a></li>
                    <li><a href="sign_up.html">sign up</a></li>
                </ul>
            </li>
            <li class="has-children">
                <a href="#">dashboard</a>
                <ul class="cd-secondary-dropdown is-hidden">
                    <li class="go-back"><a href="#0">Menu</a>
                    </li>
                    <li class="has-children"> <a href="#">candidate</a>
                        <ul class="cd-secondary-dropdown is-hidden">
                            <li class="go-back"><a href="#0">Menu</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_applied_job.html">applied job </a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_dashboard.html">dashboard</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_edit_profile.html"> edit profile</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_favourite_job.html">favourite job</a>
                            </li>
                            <li>
                                <a href="../dashboard/candidate_resume.html"> resume</a>
                            </li>
                            <li>
                                <a href="../dashboard/message.html"> message</a>
                            </li>
                            <li>
                                <a href="../dashboard/pricing_plans.html">pricing plans</a>
                            </li>
                        </ul>
                        <!-- .cd-secondary-dropdown -->
                    </li>
                    <!-- .has-children -->
                    <li class="has-children"> <a href="#">company</a>
                        <ul class="cd-secondary-dropdown is-hidden">
                            <li class="go-back"><a href="#0">Menu</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_applications.html"> applications </a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_company_page.html">company page</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_employer_dashboard.html"> dashboard</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_employer_edit_profile.html">edit profile</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_employer_manage_jobs.html"> manage jobs</a>
                            </li>
                            <li>
                                <a href="../dashboard/comp_post_new_job.html"> post new job</a>
                            </li>
                            <li>
                                <a href="../dashboard/message.html">message</a>
                            </li>
                            <li>
                                <a href="../dashboard/pricing_plans.html">pricing plans</a>
                            </li>
                        </ul>
                        <!-- .cd-secondary-dropdown -->
                    </li>
                </ul>
                <!-- .cd-secondary-dropdown -->
            </li>
            <li class="has-children">
                <a href="#">blog</a>
                <ul class="cd-secondary-dropdown icon_menu is-hidden">
                    <li class="go-back"><a href="#0">Menu</a></li>
                    <li><a href="blog_single.html">blog single</a></li>
                    <li><a href="blog_category_right_sidebar.html">blog category</a></li>
                </ul>
            </li>
            <li><a href="/contacts">contact us </a></li>
            <li><a href="/login">login</a></li>
        </ul>
        <!-- .cd-dropdown-content -->
    </nav>
    <div class="cp_navi_main_wrapper jb_cover">
        <div class="container-fluid">
            <div class="cp_logo_wrapper">
                <a href="/">
                    <img src="<?php echo e(asset('images/glowork-logo.jpg')); ?>" width="185" height="45" alt="logo">
                </a>
            </div>
            <!-- mobile menu area start -->
            <header class="mobail_menu d-block d-sm-block d-md-block d-lg-none d-xl-none">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="cd-dropdown-wrapper">
                                <a class="house_toggle" href="#0">
                                    <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="Capa_1" x="0px" y="0px" viewBox="0 0 31.177 31.177" style="enable-background:new 0 0 31.177 31.177;" xml:space="preserve" width="25px" height="25px">
                                        <g>
                                            <g>
                                                <path class="menubar" d="M30.23,1.775H0.946c-0.489,0-0.887-0.398-0.887-0.888S0.457,0,0.946,0H30.23    c0.49,0,0.888,0.398,0.888,0.888S30.72,1.775,30.23,1.775z" fill="#004165" />
                                            </g>
                                            <g>
                                                <path class="menubar" d="M30.23,9.126H12.069c-0.49,0-0.888-0.398-0.888-0.888c0-0.49,0.398-0.888,0.888-0.888H30.23    c0.49,0,0.888,0.397,0.888,0.888C31.118,8.729,30.72,9.126,30.23,9.126z" fill="#004165" />
                                            </g>
                                            <g>
                                                <path class="menubar" d="M30.23,16.477H0.946c-0.489,0-0.887-0.398-0.887-0.888c0-0.49,0.398-0.888,0.887-0.888H30.23    c0.49,0,0.888,0.397,0.888,0.888C31.118,16.079,30.72,16.477,30.23,16.477z" fill="#004165" />
                                            </g>
                                            <g>
                                                <path class="menubar" d="M30.23,23.826H12.069c-0.49,0-0.888-0.396-0.888-0.887c0-0.49,0.398-0.888,0.888-0.888H30.23    c0.49,0,0.888,0.397,0.888,0.888C31.118,23.43,30.72,23.826,30.23,23.826z" fill="#004165" />
                                            </g>
                                            <g>
                                                <path class="menubar" d="M30.23,31.177H0.946c-0.489,0-0.887-0.396-0.887-0.887c0-0.49,0.398-0.888,0.887-0.888H30.23    c0.49,0,0.888,0.398,0.888,0.888C31.118,30.78,30.72,31.177,30.23,31.177z" fill="#004165" />
                                            </g>
                                        </g>
                                    </svg>
                                </a>
                                <!-- .cd-dropdown -->

                            </div>
                        </div>
                    </div>
                </div>
                <!-- .cd-dropdown-wrapper -->
            </header>
            <div class="menu_btn_box header_btn jb_cover">
                <ul>
                <?php if(!Auth::check()): ?>
                    <li>
                        <a href="/register"><i class="flaticon-man-user"></i> sign up</a>
                    </li>
                    <li>
                        <a href="/login"> <i class="flaticon-login"></i> login</a>
                    </li>
                </ul>
                <?php else: ?> 

  <li>
                        <a href="/dashboard/index"> <i class="fa fa-user"></i> <?php echo e(Auth::user()->name); ?></a>
                    </li>

                <?php endif; ?>
            </div>

            <div class="jb_navigation_wrapper">
                <div class="mainmenu d-xl-block d-lg-block d-md-none d-sm-none d-none">
                    <ul class="main_nav_ul">
                        <li class="has-mega gc_main_navigation"><a href="/" class="gc_main_navigation active_class">home</a>
             
                        </li>
                                       <li><a href="/aboutus" class="gc_main_navigation">About Glowork</a></li>

                      
                        <li class="has-mega gc_main_navigation"><a href="/jobs" class="gc_main_navigation">Jobs</a>
                       <!--     <ul class="navi_2_dropdown">
                                <li class="parent">
                                    <a href="#"><i class="fas fa-square"></i>Jobs By Category<span><i class="fas fa-chevron-right"></i>
									</span></a>
                                    <ul class="dropdown-menu-right">
                                    <?php $__currentLoopData = App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                         <li>
                                            <a href="<?php echo e(route('category.index' , $category->id)); ?>"> <i class="fas fa-square"></i><?php echo e($category->name); ?> </a>
                                        </li>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                 
                                    </ul>
                                </li>
                                <li class="parent">
                                    <a href="#"><i class="fas fa-square"></i>Jobs By City<span><i class="fas fa-chevron-right"></i>
									</span></a>
                                    <ul class="dropdown-menu-right">
                                    <?php $__currentLoopData = App\City::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       <li>
                                            <a href="<?php echo e(route('city.index' , $city->id)); ?>"> <i class="fas fa-square"></i><?php echo e($city->name); ?> </a>
                                        </li>  
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  
                                    </ul>
                                </li>

                            </ul> -->
                        </li>
                        
       <li class="has-mega gc_main_navigation"><a href="#" class="gc_main_navigation">Our Services
</a>
                            <ul class="navi_2_dropdown">
                            
                                <li class="parent">
                                    <a href="/staff"><i class="fas fa-square"></i>Hiring Staff</a>
                                    <a href="/sessions"><i class="fas fa-square"></i>Coaching</a>
                                     <a href="#"><i class="fas fa-square"></i>Our Events</a>
                                </li>

                            </ul>
                        </li>

                        <li><a href="/contact" class="gc_main_navigation">contact</a></li>

                    </ul>
                </div>
                <!-- mainmenu end -->
                <div class="jb_search_btn_wrapper d-none d-sm-none d-md-none d-lg-block d-xl-block">
                    <!-- extra nav -->
                    <div class="extra-nav">
                        <div class="extra-cell">
                            <button id="quik-search-btn" type="button" class="site-button radius-xl"><i class="fas fa-search"></i></button>
                        </div>
                    </div>

                    <!-- Quik search -->
                    <div class="dez-quik-search bg-primary-dark">
                        <form action="#">
                            <input name="search" value="" type="text" class="form-control" placeholder="Type to search...">
                            <span id="quik-search-remove"><i class="fas fa-times"></i></span>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>



    <!-- navi wrapper End -->
    <!-- top header wrapper start -->
    <div class="page_title_section">

        <div class="page_header">
            <div class="container">
                <div class="row">
                    <!-- section_heading start -->
                    <div class="col-lg-9 col-md-9 col-12 col-sm-8">

                        <h1>About us </h1>
                    </div>
                    <div class="col-lg-3 col-md-3 col-12 col-sm-4">
                        <div class="sub_title_section">
                            <ul class="sub_title">
                                <li> <a href="#"> Home </a>&nbsp; / &nbsp; </li>
                                <li>About us </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- top header wrapper end -->
    <!-- work Wrapper Start -->
    <div class="iner_abt_wrapper jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-12 col-sm-12">
                    <div class="about_slider_wrapper float_left">
                        <div class="owl-carousel owl-theme">
                         <!--   <div class="item">
                               <div class="about_image">
                             <img src="images/Picture1.png" width="1173" height="450" class="img-responsive" alt="">

                                </div> 
                            </div> -->
                            <div class="item">
                                <div class="about_image">
                                    <img src="images/Khalid-Sulaiman-Al-Saleh.png" width="750" height="400" class="img-responsive" alt="">
                                </div>
                            </div>
                        
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-10 col-md-12 col-12 col-sm-12 offset-lg-1">
                    <div class="about_text_wrapper">
                        <p>“In 2011, together with my two friends, we founded Glowork with the purpose of unleashing women's potential, and advancing the evolution of women as leaders, innovators, entrepreneurs, and creators all over the kingdom. Glowork is dedicated to empowering women and girls to lead, to create our future, and to transform our country.
We celebrate our female entrepreneurs who have defied odds and are nurturing viable businesses to date. We celebrate the mindset shifts, and the outcomes we have obtained in our women empowerment drive as an organization.”</p>
                        <h5> - by <span> Khalid Sulaiman Al-Saleh
</span> (CEO) </h5>
                        <img src="images/signs.png" height="75" alt="img">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- work Wrapper end -->
    <!-- counter wrapper start-->
 
    <!-- counter wrapper end-->
    <!-- job agency Wrapper Start 
    <div class="job_agency_wrapper jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-12 col-sm-12">
                    <div class="jb_heading_wraper left_jb_jeading">

                        <h3>We Iusto Creative Digital 
Agency, We Provide 
Professional Web Page.</h3>

                    </div>
                    <div class="grow_next_text agency_main_wrapper jb_cover">
                        <p>What do all consultants need? In short, trust. This is achprofessional presentation and the ability to communicateclearly with existing and potential clients. Whether you are an accountant,What do all consultants need? In short, trust. This is achieved with professional presentation and the ability to communicate.
                            <br>
                            <br> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut ed minim veniam, quis nostrud dipisicing elit, sed do eiusmod tempor incididunt exercitationlaborum. </p>
                        <div class="header_btn search_btn jb_cover">

                            <a href="#">learn more</a>

                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-12 col-sm-12">
                    <div class="row">

                        <div class="col-lg-6 col-md-6 col-12 col-sm-12">
                            <div class="company_main_wrapper">
                                <div class="company_img_wrapper">
                                    <img src="images/cmp3.png" alt="team_img1">
                                    <div class="btc_team_social_wrapper">
                                        <h1>(usa)</h1>
                                    </div>
                                </div>
                                <div class="opening_job">
                                    <h1><a href="#">25 job open</a></h1></div>
                                <div class="company_img_cont_wrapper">
                                    <h4>burger patty</h4>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-6 col-12 col-sm-12">
                            <div class="company_main_wrapper">
                                <div class="company_img_wrapper">
                                    <img src="images/cmp4.png" alt="team_img1">
                                    <div class="btc_team_social_wrapper">
                                        <h1>(usa)</h1>
                                    </div>
                                </div>
                                <div class="opening_job">
                                    <h1><a href="#">04 job open</a></h1></div>
                                <div class="company_img_cont_wrapper">
                                    <h4>Akshay INC.</h4>

                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="jb_top_jobs_category job_agency_box jb_cover">

                                <h3><a href="#">laravel</a></h3>
                                <img src="images/jb1.png" alt="img">

                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="jb_top_jobs_category job_agency_box jb_cover">

                                <h3><a href="#">Wordpress</a></h3>
                                <img src="images/jb2.png" alt="img">

                            </div>
                        </div>
                        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12">
                            <div class="jb_top_jobs_category job_agency_box jb_cover">

                                <h3><a href="#">AngularJS</a></h3>
                                <img src="images/jb3.png" alt="img">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

 -->
    <!-- team wrapper start-->
    <div class="team_wrapper jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1 col-md-12 col-sm-12">
                    <div class="jb_heading_wraper">

                        <h3>Meet Our Expert Team Member</h3>

                    </div>
                </div>
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="team_slider_wrapper jb_cover">
                        <div class="owl-carousel owl-theme">
                            <div class="item">

                                <div class="team_slider_content jb_cover">
                                    <div class="team_slider_img_box jb_cover">
                                        <img src="images/Khalid-Sulaiman-Al-Saleh.png" width="393" height="300" alt="img" class="img-responsive">
                                    </div>
                                    <div class="team_slider_content_btm jb_cover">
                                        <p>CEO</p>
                                        <h2><a href="#">Khalid Sulaiman Al-Saleh</a></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="item">

                                <div class="team_slider_content jb_cover">
                                    <div class="team_slider_img_box jb_cover">
                                        <img src="images/glowork_women.png" width="325" height="275"  alt="img" class="img-responsive">
                                    </div>
                                    <div class="team_slider_content_btm jb_cover">
                                        <p>Project and Business Development Manager</p>
                                        <h2><a href="mailto: Ebtiehal.AlBakr@glowork.net">Ebtiehal AlBakr</a></h2>
                                    </div>
                                </div>
                            </div>

                            <div class="item">

                                <div class="team_slider_content jb_cover">
                                    <div class="team_slider_img_box jb_cover">
                                        <img src="images/glowork_women.png" width="325" height="275"  alt="img" class="img-responsive">
                                    </div>
                                    <div class="team_slider_content_btm jb_cover">
                                        <p>Marketing Communication Specialist</p>
                                        <h2><a href="mailto: Nujud.Algammash@glowork.net">Nujud Algammash</a></h2>
                                    </div>
                                </div>
                            </div>

                               <div class="item">

                                <div class="team_slider_content jb_cover">
                                    <div class="team_slider_img_box jb_cover">
                                        <img src="images/glowork_women.png" width="325" height="275" alt="img" class="img-responsive">
                                    </div>
                                    <div class="team_slider_content_btm jb_cover">
                                        <p>PMO</p>
                                        <h2><a href="#">Raeda Alqahtani</a></h2>
                                    </div>
                                </div>
                            </div>
                                   <div class="item">

                                <div class="team_slider_content jb_cover">
                                    <div class="team_slider_img_box jb_cover">
                                        <img src="images/glowork_women.png" width="325" height="275" alt="img" class="img-responsive">
                                    </div>
                                    <div class="team_slider_content_btm jb_cover">
                                        <p>Business Development Senior Officer</p>
                                        <h2><a href="mailto: Noura.AlAmmar@glowork.net">Noura AlAmmar</a></h2>
                                    </div>
                                </div>
                            </div>
                                   <div class="item">

                                <div class="team_slider_content jb_cover">
                                    <div class="team_slider_img_box jb_cover">
                                        <img src="images/glowork_women.png" width="325" height="275" alt="img" class="img-responsive">
                                    </div>
                                    <div class="team_slider_content_btm jb_cover">
                                        <p>Recruitment Manager</p>
                                        <h2><a href="mailto: noura.alqahtani@glowork.net">Noura Alqahtani </a></h2>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- team wrapper end-->
    <!-- job rivew wrapper start
    <div class="job_rivew_wrapper jb_cover">
        <div class="job_rivew_img">
            <img src="images/mockup3.png" alt="img">
        </div>
        <div class="job_rivew_testimonial">
            <div class="jb_heading_wraper left_rivew_heading">

                <h3>Objectives</h3>

                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit,
                    <br> sed do eiusmod tempor incididunt </p>
            </div>
            <div class="rivew_testimonial_slider jb_cover">
                <div class="owl-carousel owl-theme">
                    <div class="item">

                        <div class="jb_saying_content_wrapper jb_cover">
                            <div class="saying_img">
                                <img src="images/testi.png" alt="img">
                            </div>
                            <div class="rating_star"><i class="flaticon-star-1"></i><i class="flaticon-star-1"></i><i class="flaticon-star-1"></i><i class="flaticon-star"></i><i class="flaticon-star"></i></div>

                            <p>“ I dont always clap, but when I do, itsbecause of Sella. We can't understandhow we've been Sella. ”</p>
                            <div class="jb_saying_img_name">
                                <h1><a href="#">Marita Irene</a></h1>
                                <p>Support Manager @ Echo</p>
                            </div>
                        </div>
                    </div>

                    <div class="item">
                        <div class="jb_saying_content_wrapper jb_cover">
                            <div class="saying_img">
                                <img src="images/testi1.png" alt="img">
                            </div>
                            <div class="rating_star"><i class="flaticon-star-1"></i><i class="flaticon-star-1"></i><i class="flaticon-star-1"></i><i class="flaticon-star"></i><i class="flaticon-star"></i></div>
                            <p>“ I don't always clap, but when I do, it'sbecause of Sella. We can't understandhow we've been Sella. ”</p>
                            <div class="jb_saying_img_name">
                                <h1><a href="#">Marita Irene</a></h1>
                                <p>Support Manager @ Echo</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    job rivew wrapper end-->
    <!--
    
     <div class="download_wrapper jb_cover">
        <div class="counter_overlay"></div>
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="download_mockup_design jb_cover">
                        <div class="animation-circle-inverse2"><i></i><i></i><i></i></div>
                        <img src="images/mockup5.png" class="img-responsive" alt="img">
                    </div>
                </div>
                <div class="col-lg-6 col-md-12 col-sm-12 col-xs-12">
                    <div class="download_app_store jb_cover">
                        <h4 style="color:white">Cooming Soon</h4>
                        <h2>Glowork Job Portal App !</h2>
                        <p>All it takes is 30 seconds to Download. Your Mobile App for Job
                            <br> Fast, Simple & Delightful.</p>
                        <div class="app_btn jb_cover">
                            <a href="#" class="ss_playstore"><span><i class="flaticon-android-logo"></i></span> Play Store</a>
                            <a href="#" class="ss_appstore"><span><i class="flaticon-apple"></i></span> App Store</a>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    
     download app wrapper start-->
    
    <!-- footer Wrapper Start -->
    <div class="footer jb_cover">

        <div class="container">
            <div class="row">
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover">
                        <a href="#"><img src="<?php echo e(asset('images/glowork-logo.jpg')); ?>" width="225" height="105" alt="img"></a>
                        <ul class="footer_first_contact">
                            <li><i class="flaticon-location-pointer"></i>
                                <p>Riyadh Gallery Mall,
                                    <br>GNo.A1-4thFloor-Office 410
                                </p>
                            </li>
                            <li><i class="flaticon-telephone"></i>
                                <p>966-11-2015533

                                    <br>966-11-2014388</p>
                            </li>
                            <li><i class="flaticon-envelope"></i><a href="#"> </a>
                                <a href="#">info@glowork.net</a>
                            </li>

                        </ul>

                        <ul class="icon_list_news jb_cover">
                            <li><a href="https://www.facebook.com/Glowork.net"><i class="fab fa-facebook-f"></i></a></li>
                            <li>
                                <a href="https://twitter.com/Glowork"><i class="fab fa-twitter"></i>
                                    </a>
                            </li>
                            <li><a href="https://www.linkedin.com/company/glowork/?originalSubdomain=sa"><i class="fab fa-linkedin-in"></i></a></li>
                            <li><a href="#"><i class="fab fa-google-plus-g"></i></a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover footer_border_displ">
                        <h5>features</h5>
                        <ul class="nav-widget">
                            <li><a href="/admin"><i class="fa fa-square"></i>Admin Portal</a></li>

     
                            <li><a href="/dashboard/index"><i class="fa fa-square"></i>Client Portal
</a></li>

            


                            <li><a href="#"><i class="fa fa-square"></i>Virtual Offices</a></li>

                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover footer_border_displ">
                        <h5>browse</h5>
                        <ul class="nav-widget">

                            <li><a href="/jobs"><i class="fa fa-square"></i>browse by Category</a></li>

                            <li><a href="/jobs"><i class="fa fa-square"></i>browse by City</a></li>


                            <li><a href="/jobs"><i class="fa fa-square"></i> find jobs</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 col-12">
                    <div class="footerNav jb_cover footer_border_displ">
                        <h5>app & integration</h5>
                        <ul class="nav-widget">
                            <li>
                                <a href="#"><img src="<?php echo e(asset('images/ft1.png')); ?>" alt="img">Xero
                                </a>
                            </li>

                            <li>
                                <a href="#"><img src="<?php echo e(asset('images/ft2.png')); ?>" alt="img">Reckon
                                </a>
                            </li>

                            <li>
                                <a href="#"><img src="<?php echo e(asset('images/ft3.png')); ?>" alt="img">Flexidocs
                                </a>
                            </li>
                            <li>
                                <a href="#"><img src="<?php echo e(asset('images/ft4.png')); ?>" alt="img">Microsoft Exchange</a>
                            </li>
                            <li>
                                <a href="#"><img src="<?php echo e(asset('images/ft5.png')); ?>" alt="img"> Mailchimp
                                </a>
                            </li>
                            <li>
                                <a href="#"><img src="<?php echo e(asset('images/ft6.png')); ?>" alt="img"> MYOB
                                </a>
                            </li>

                        </ul>
                    </div>
                </div>
                <div class="copyright_left"><i class="fa fa-copyright"></i> 2021 <a href="#">  Glowork.  </a> All Rights Reserved.
                </div>

                <div class="clearfix"></div>
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
        <!-- 
        <div class="waveWrapper waveAnimation">
            <div class="waveWrapperInner bgTop gradient-color">
                <div class="wave waveTop"></div>
            </div>
            <div class="waveWrapperInner bgMiddle">
                <div class="wave waveMiddle"></div>
            </div>
            <div class="waveWrapperInner bgBottom">
                <div class="wave waveBottom"></div>
            </div>
        </div>
--> 
    </div>

    <!-- footer Wrapper End -->

	 <!-- chat box Wrapper start -->
	<div id="chat-circle" class="btn btn-raised"> 
		<i class="fas fa-comment-alt"></i>
	</div>
  <div class="chat-box">
    <div class="chat-box-header">
      ChatBot
      <span class="chat-box-toggle"><i class="fas fa-times"></i></span>
    </div>
    <div class="chat-box-body">
      <div class="chat-box-overlay">   
      </div>
      <div class="chat-logs">
       
      </div><!--chat-log -->
    </div>
    <div class="chat-input">      
      <form>
        <input type="text" id="chat-input" placeholder="Send a message..."/>
      <button type="submit" class="chat-submit" id="chat-submit"><i class="fas fa-paper-plane"></i></button>
      </form>      
    </div>
  </div>
  <!-- chat box Wrapper end -->
    <!--custom js files-->
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/modernizr.js"></script>
    <script src="js/jquery.menu-aim.js"></script>
    <script src="js/plugin.js"></script>
    <script src="js/owl.carousel.js"></script>
    <script src="js/jquery.countTo.js"></script>
    <script src="js/dropify.min.js"></script>
	<script src="js/jquery-ui.js"></script>
    <script src="js/jquery.inview.min.js"></script>
	 <script src="js/jquery.magnific-popup.js"></script>
    <script src="js/jquery.nice-select.min.js"></script>
    <script src="js/imagesloaded.pkgd.min.js"></script>
    <script src="js/isotope.pkgd.min.js"></script>
    <script src="js/custom.js"></script>
    <!-- custom js-->
    <script>
    </script>
</body>

</html><?php /**PATH C:\Users\Ibrahim Elsanhouri\Desktop\glowork\resources\views/aboutus.blade.php ENDPATH**/ ?>