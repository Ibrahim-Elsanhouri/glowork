
<?php $__env->startSection('content'); ?>
<!-- navi wrapper End -->
    <!-- top header wrapper start -->
    <div class="page_title_section">

        <div class="page_header">
            <div class="container">
                <div class="row">
                    <!-- section_heading start -->
                    <div class="col-lg-9 col-md-8 col-12 col-sm-7">

                        <h1>Our Events</h1>
                    </div>
                    <div class="col-lg-3 col-md-4 col-12 col-sm-5">
                        <div class="sub_title_section">
                            <ul class="sub_title">
                                <li> <a href="/"> Home </a>&nbsp; / &nbsp; </li>
                                <li>Our Events</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- top header wrapper end -->
    <!--job listing filter  wrapper start-->
    <div class="blog_ct_right_wrapper jb_cover">
        <div class="container">

            <div class="row">
                <div class="col-lg-9 col-md-12 col-sm-12 col-12">


<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
                    <div class="jp_first_blog_post_main_wrapper jb_cover">
                        <div class="jp_first_blog_post_img">
                            <img src="/<?php echo e($event->image); ?>" width="795" height="410" class="img-responsive" alt="blog_img" />
                        </div>
                        <div class="jp_first_blog_post_cont_wrapper">
                            <p><span><?php echo e($event->date); ?></span></p>
                            <h3><a href="#"><?php echo e($event->name); ?> 

</a></h3>
                            <p>
                            <?php echo e($event->description); ?>

                            
                            
                            </p>
                                                    <p><a href="#">Place : <?php echo e($event->place); ?> 

</a></p>
                        </div>
                       
                    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


              

                
                 
                    <div class="blog_pagination_section pd22 jb_cover">
              
                    </div>

                </div>
                <div class="col-lg-3 col-md-12 col-sm-12 col-12">
                   
                    <div class="job_filter_category_sidebar jb_cover">
                        <div class="job_filter_sidebar_heading jb_cover">
                            <h1>Job Categories</h1>
                        </div>

                        <div class="category_jobbox jb_cover">
                            <ul class="blog_category_link jb_cover">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><i class="fa fa-caret-right"></i> <a href="#"><?php echo e($category->name); ?> <span>(<?php echo e($category->jobs->count()); ?>)</span></a></li>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            </ul>
                        </div>
                    </div>
             
                    <div class="job_filter_category_sidebar jb_cover">
                        <div class="job_filter_sidebar_heading jb_cover">
                            <h1>job spotlight</h1>
                        </div>

                        <div class="category_jobbox jb_cover">
                            <div class="jp_spotlight_slider_wrapper">
                                <div class="owl-carousel owl-theme">

                                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                              <div class="item">
                                        <div class="jp_spotlight_slider_img_Wrapper">
                                            <img src="/<?php echo e($job->image); ?>" width="221" height="130" alt="spotlight_img" />
                                        </div>
                                        <div class="jp_spotlight_slider_cont_Wrapper">
                                            <h4><?php echo e($job->title->name); ?></h4>

                                            <p><a href="#"><?php echo e($job->nature->name); ?></a></p>
                                            <ul>
                                                <li><i class="far fa-flag"></i>&nbsp; <?php echo e($job->nationality); ?></li>
                                            </ul>
                                        </div>
                                        <div class="header_btn search_btn news_btn overview_btn  jb_cover">

                                            <a href="/jobs">apply now !</a>

                                        </div>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          


                                  
                                
                                </div>
                            </div>
                        </div>
                    </div>
              
                 
                </div>
            </div>
        </div>
    </div>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahim/Desktop/glowork/resources/views/events/index.blade.php ENDPATH**/ ?>