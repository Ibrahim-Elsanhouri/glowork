<br><br>

<?php if(session('info')): ?>
<div class="container">
    <div class="alert alert-info">
    <center>    <?php echo e(session('info')); ?> </center>
    </div>
	</div>
<?php endif; ?>



<?php if(session('danger')): ?>
<div class="container">

    <div class="alert alert-danger">
    <center>    <?php echo e(session('danger')); ?> </center>
    </div>
		</div>

<?php endif; ?>

<?php if(session('success')): ?>
<div class="container">

    <div class="alert alert-success">
    <center>    <?php echo e(session('success')); ?> </center>
    </div>
		</div>

<?php endif; ?><?php /**PATH /home/ibrahim/Desktop/glowork/resources/views/layouts/alerts.blade.php ENDPATH**/ ?>