        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> 


<?php $__env->startSection('content'); ?>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.js"></script> 


    <!-- navi wrapper End -->
    <!-- top header wrapper start -->
    <div class="page_title_section">

        <div class="page_header">
            <div class="container">
                <div class="row">
                    <!-- section_heading start -->
                    <div class="col-lg-9 col-md-8 col-12 col-sm-7">

                        <h1>sign up</h1>
                    </div>
                    <div class="col-lg-3 col-md-4 col-12 col-sm-5">
                        <div class="sub_title_section">
                            <ul class="sub_title">
                                <li> <a href="#"> Home </a>&nbsp; / &nbsp; </li>
                                <li>sign up</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- top header wrapper end -->
    <!-- sign up wrapper start -->
    <div class="login_wrapper jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="login_top_box jb_cover">
                        <div class="login_banner_wrapper">
                            <div class="header_btn search_btn facebook_wrap jb_cover">


                            </div>
                            <div class="header_btn search_btn google_wrap jb_cover">


                            </div>
                        
                        </div>
                        <div class="login_form_wrapper signup_wrapper">
                            <h2>sign up</h2>
							   <div class="form-group icon_form comments_form">
    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>
                                <input type="text" class="form-control  <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> require" name="name" id="name" placeholder=" Name*" value="<?php echo e(old('name')); ?>" required autocomplete="name" autofocus>
                                
                                
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <i class="fas fa-user"></i>
                            </div>
                             <div class="form-group icon_form comments_form">

                                <input type="text" class="form-control require <?php $__errorArgs = ['identified'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="identified" id="identified" placeholder="National ID or Iqama*" value="<?php echo e(old('identified')); ?>" required autocomplete="identified">

                                <?php $__errorArgs = ['identified'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
<i class="far fa-id-card"></i>

                            </div>
                            <div class="form-group icon_form comments_form">

                                <input type="email" class="form-control require <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email" id="email" placeholder="Email Address*" value="<?php echo e(old('email')); ?>" required autocomplete="email">

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <i class="fas fa-envelope"></i>
                            </div>
                                       <div class="form-group icon_form comments_form">

                                <input type="password" class="form-control require <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" id="password" placeholder="Password" value="<?php echo e(old('password')); ?>" required autocomplete="password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                <i class="fas fa-lock"></i>
                            </div>
                            <div class="form-group icon_form comments_form">

                                <input type="password"  id="password-confirm" class="form-control require"  name="password_confirmation" required autocomplete="new-password" placeholder="Password Confirmation">
                                <i class="fas fa-lock"></i>
                            </div>
               
                             <div class="form-group icon_form comments_form">

                                <input type="text" class="form-control require" name="mobile" placeholder="Mobile">
                                <i class="fas fa-phone"></i>
                            </div>


                             <div class="form-group icon_form comments_form">

                                <input type="text" class="form-control require" name="skills" placeholder="Area of expertise skills">
                               </i><i class="fab fa-angellist"></i>
                            </div>
                              <div class="form-group icon_form comments_form">

                                <input type="file" class="form-control require" name="resume" placeholder="Mobile">
                                <i class="fas fa-file"></i>
                            </div>

                            <div class="form-group icon_form comments_form">





<div class="row">
<div class="col-md-6">
   <select name="categories_id" style="width: 1000px;">
                               <option> ---  Specialization --- </option>
                               <?php $__currentLoopData = \App\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>

                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                               </select>
</div>
<div class="col-md-6">
   <select name="qualification" style="width: 1000px;">
                               <option> ---  Qualification --- </option>
                            <option value="Master’s degree">Master’s degree</option>
                            <option value="Bachelor’s degree">Bachelor’s degree</option>
                            <option value="Diploma">Diploma</option>
                            <option value="Secondary ">Secondary </option>
                            <option value="Average">Average</option>
                            <option value="Ph.D.">Ph.D.</option>


                               </select>
</div>
</div>
<br>
<div class="row">
<div class="col-md-6">
   <select name="gyear" style="width: 1000px;">
                               <option> ---  Graduation Yaer --- </option>
                            <option value="2020">2020</option>
                            <option value="2019">2019</option>
                            <option value="2018">2018</option>
                            <option value="2017">2017</option>
                            <option value="2016">2016</option>
 <option value="2015">2015</option>
                            <option value="2014">2014</option>
                            <option value="2013">2013</option>
                            <option value="2012">2012</option>
                            <option value="2011">2011</option>
                            <option value="2010">2010</option>
                            <option value="2009">2009</option>
                            <option value="2008">2008</option>
                            <option value="2007">2007</option>
                            <option value="2006">2006</option>
                            <option value="2005">2005</option>
 <option value="2004">2004</option>
                            <option value="2003">2003</option>
                            <option value="2002">2002</option>
                            <option value="2001">2001</option>
                            <option value="2000">2000</option>
                            <option value="2010">2010</option>
                               </select>
</div>
<div class="col-md-6">
   <select name="experience" style="width: 1000px;">
                               <option> --- Years of Experience --- </option>
                            <option value="Fresher">Fresher</option>
                            <option value="1-2 Years">1-2 Years</option>
                            <option value="1-2 Years">1-2 Years</option>
                            <option value="2-3 Years">2-3 Years</option>

                            <option value="More than 3 Years">More than 3 Years</option>

                               </select>
</div>

</div>
   
</div>

   
    

                            <div class="login_remember_box">
                         
                         
                            </div>
                            <div class="header_btn search_btn login_btn jb_cover">

                                <button type="submit" class="btn btn-danger btn-lg">sign up</button>
                            </div>
                            <div class="dont_have_account jb_cover">
                                <p> have an acount ? <a href="/login">login</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- sign up wrapper end -->

    <!-- news app wrapper start-->
    <div class="news_letter_wrapper jb_cover">
        <div class="container">
            <div class="row">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="job_newsletter_wrapper jb_cover">
                        <div class="jb_newslwtteter_left">
                        </div>
                        <div class="jb_newslwtteter_button">
                      
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>










<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ibrahim/Desktop/glowork/resources/views/auth/register.blade.php ENDPATH**/ ?>